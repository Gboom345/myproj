import platform

print("Retrieving System information…\n")
print(f"System: {platform.system()}")
print(f"Hostname: {platform.node()}")
